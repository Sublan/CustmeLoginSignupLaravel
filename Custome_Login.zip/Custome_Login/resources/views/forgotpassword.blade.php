<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
</head>
<body>
	<div class="container ">
		<div class="row text-center  d-flex justify-content-center " >
			<div class="card card-default">
				<div class="card-header">
					Email To Send a Password Reset Link
				</div>
				<div class="card-body">
					@if(session()->has('No-Email'))
						<div class="alert alert-danger">
							{{session()->get('No-Email')}}
						</div>

					@endif
					@if(session()->has('Email_Sent'))
						<div class="alert alert-danger">
							{{session()->get('Email_sent')}}
						</div>
					@endif
					
					@if(session()->has('Email_Sending_fails'))
						<div class="alert alert-danger">
							{{session()->get('Email_Sending_fails')}}
						</div>
					@endif

					<form class="form" action="{{route('Send-Reset-Email')}}" method="POST" class="form-horizontal">
						@csrf
						<div class="input-group">
							<input class="form-control" type="email" placeholder="Email" name="email" required="yes"></input>	
						</div>
						<!-- <div class="input-group">
							<input class="form-control" placeholder="New Password" name="password" type="password" required="yes" minlength="8" maxlength="20"></input>	
						</div> -->
						<div class="input-group">
							<button class="btn btn-sm btn-primary p-20 mx-auto" type="submit">Generated and send Link 
							</button>
						</div>
						
					</form>
				</div>
			</div>
		</div>


	</div>

</body>
</html>