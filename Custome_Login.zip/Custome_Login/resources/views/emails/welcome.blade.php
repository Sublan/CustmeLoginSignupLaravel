@component('mail::message')
# Introduction

Click On Reset Password To Reset Password

@component('mail::button', ['url' => $link  . $token ])
Reset Password
@endcomponent
Thanks,<br>
{{ config('app.name') }}
@endcomponent
