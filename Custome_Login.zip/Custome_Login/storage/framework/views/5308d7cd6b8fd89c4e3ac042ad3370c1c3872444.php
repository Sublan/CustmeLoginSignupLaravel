<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
</head>
<body>
	<h1 class="heading">Welcome To Dashboard</h1>

	<?php if(session()->has('Login_Success')): ?>
		<div class="alert alert-success">
			
			 <?php echo e(session()->get('Login_Success')); ?> 

		</div>
		<?php endif; ?>
		<a href="/logout" class="btn btn-danger btn-sm">Logout</a>
</body>
</html><?php /**PATH C:\laragon\www\Custome_Login\resources\views//home.blade.php ENDPATH**/ ?>