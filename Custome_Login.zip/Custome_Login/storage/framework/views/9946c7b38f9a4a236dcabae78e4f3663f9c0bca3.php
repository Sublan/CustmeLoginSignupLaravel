<!DOCTYPE html>
<html>
<head>
	<title>Reset Password</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<div class="row text-center" >
			<div class="card card-default">
				<div class="card-header">
					Reset Password
				</div>
				<div class="card-body">

					<?php if(session()->has('Reset')): ?>

							<div class="alert alert-success">
								
								<?php echo e(session()->get('Reset')); ?>

							</div>

					<?php endif; ?>
					<form class="form" action="<?php echo e(route('Password-Resets')); ?>" method="POST" class="form-horizontal">
						<?php echo csrf_field(); ?>
						<div class="input-group">
							<input class="form-control" type="password" required="yes" minlength="8" maxlength="20" placeholder="New Password" name="new-password"></input>	
						</div>
						<div class="input-group">
							<button class="btn btn-sm btn-primary" type="submit">Reset Passsword</button>
						</div>
						
					</form>
				</div>
			</div>
		</div>


	</div>

</body>
</html><?php /**PATH C:\laragon\www\Custome_Login\resources\views/reset.blade.php ENDPATH**/ ?>