<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="container">

<div class="card card-default text-center">
<div class="card-header">Login Here</div>

<div class="row justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-12">
        
        
        
        <div class="card-body">
    <div id="loginbox" style="margin-top:50px;" class="mainbox">                    
        <div class="panel panel-info" >
                <div class="panel-heading">
                    <div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="<?php echo e(route('Passsword-Reset')); ?>">Forgot password?</a></div>
                </div>     

                <div style="padding-top:30px" class="panel-body">

                    <div class="col-sm-12">
                       

                         <?php if(session()->has('Password-Updated')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session()->get('Password-Updated')); ?> 
                                </div>
                        <?php endif; ?>    
                    
                    <?php if(session()->has('LoginError')): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e(session()->get('LoginError')); ?> 
                                </div>
                        <?php endif; ?>    
                        <?php if(session()->has('success')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session()->get('success')); ?> 
                                </div>
                        <?php endif; ?>  
                        <?php if(session()->has('Email')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session()->get('Email')); ?> 
                                </div>
                        <?php endif; ?>  

                         <?php if(session()->has('MustLogin')): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e(session()->get('MustLogin')); ?> 
                                </div>
                        <?php endif; ?>   

                         <?php if(session()->has('Email_Sent')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session()->get('Email_Sent')); ?> 
                                </div>
                        <?php endif; ?> 

                         <?php if(session()->has('Email_Sending_fails')): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e(session()->get('Email_Sending_fails')); ?> 
                                </div>
                        <?php endif; ?>     
                
                    </div>

                    
                        
                    <form id="loginform" class="form-horizontal" role="form" action="<?php echo e(route('Login.Verification')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                        <div style="margin-bottom: 25px" class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input id="login-username" type="email" required="yes" minlength="6" class="form-control" name="uemail" value="" placeholder="Email">                                        
                                </div>
                            
                        <div style="margin-bottom: 25px" class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                    <input id="login-password" required="yes" minlength="8" maxlength="25" type="password" class="form-control" name="password" placeholder="Password">
                                </div>
                                

                            
                        <div class="input-group">
                                  <div class="checkbox">
                                    <label>
                                      <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                    </label>
                                  </div>
                                </div>


                            <div style="margin-top:10px" class="form-group">
                                <!-- Button -->

                                <div class="col-sm-12 controls">
                                <button id="btn-login" class="btn btn-success" type="submit">Login</button>
    
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-md-12 control">
                                    <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                       <span class="span text-justify float-left pd-3">Don't have an account!  </span> 
                                    <a href="<?php echo e(route('signup')); ?>" class="btn btn-sm btn-primary float-right" onClick="#">
                                        Sign Up Here
                                    </a>
                                    </div>
                                </div>
                            </div>    
                        </form>     



                    </div>                     
                </div>  
    </div>       
     </div> 
</div>

        
        
        </div>

</div>






    </div>



</div>






</body>
</html><?php /**PATH C:\laragon\www\Custome_Login\resources\views//login.blade.php ENDPATH**/ ?>