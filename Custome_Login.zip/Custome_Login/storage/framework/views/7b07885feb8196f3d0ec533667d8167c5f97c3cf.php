<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <title>Signup</title>
</head>
<body>

<div class="container"> 
    <div class="card card-default text-center">  
     <div class="card-header">Sign Up</div>
        <div class="row justify-content-center">

                <div class="col-lg-6 col-md-6 col-sm-12">
     
                 <div class="card-body ">

                      <div id="loginbox" style="margin-top:50px;" class="mainbox">                        

                    <div style="padding-top:30px" class="panel-body" >

                        <div class="col-sm-12">
                        <?php if(session()->has('Email_Exists')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('Email_Exists')); ?>

                            </div>
                        <?php endif; ?>
                        
                        </div>
                            
                        <form id="loginform" class="form-horizontal" action="/StoreData" method="POST">
                                    <?php echo csrf_field(); ?>
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username"  pattern="[A-Za-z]{4,10}" required="yes" type="text" class="form-control" name="fname" value="" placeholder="First Name">                                        
                                    </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" pattern="[A-Za-z]{4,10}" required="yes" type="text" class="form-control" name="lname" value="" placeholder="Last Name">                                        
                                    </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required="yes" minlength="6" type="email" class="form-control" name="email" value="" placeholder="Email">                                        
                                    </div>
                                  <!-------  <div class="form-group">
                                            <label for="mstatus" >Merital Status:</label>
                                    <select class="form-control" id="status" name="mstatus" >
                                            <option value="single" >Single</option>
                                            <option value="married" >Married</option>
                                    </select>
                            </div>  ------->
                            <div class="">
                                    <label class="radio-inline"><input type="radio" value="male" name="gendre" checked> Male</label>
                                    <label class="radio-inline"><input type="radio" value="female" name="gendre"> Female</label>
                                    <label class="radio-inline"><input type="radio" value="others" name="gendre"> Others</label>
                            
                            </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input required="yes" minlength="8" maxlength="20" id="myInput" type="password" class="form-control" name="password" placeholder="Password">

                                    </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                       <br>
                                        <input required="yes" type="password" class="form-control" name="password_confirmation" placeholder="Re-Type password">
                                       
                                    </div>


                                <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
                                    <button class="btn btn-sm btn-success" type="submit">Sign Up</button>
                                      <a id="btn-fblogin" href="#" class="btn btn-sm btn-primary">Login with Facebook</a>

                                    </div>
                                </div>
                                <div class="form-group">
                                <div class="col-md-12 control">
                                    <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                       <span class="span text-justify float-left pd-3">Already Have an Account !  </span> 
                                    <a href="/login" class="btn btn-sm btn-primary float-right" onClick="#">
                                        Login Here
                                    </a>
                                    </div>
                                </div>
                            </div>    

                            </div>    
                            </form>     
                      </div> 
                                        
               </div>  
            </div> 
            </div>          
        </div><!--ROW div closed-->  
            
    </div> <!--card-header div closed-->  
  
    </div><!--card-div-closed div closed--> 
</div><!--Container-div closed--> 




</body>
</html><?php /**PATH C:\laragon\www\Custome_Login\resources\views/signup.blade.php ENDPATH**/ ?>