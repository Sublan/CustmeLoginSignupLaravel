<?php

namespace App\Http\Middleware;

use Closure;
use session;
use Auth;

class Authentication
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::check()){

            return $next($request);
        }

        else{
            session()->flash('MustLogin','You Must Login To Continue');
            return redirect(route('login'));
        }
        
    }
}
