<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use URL;
use DB;
use App\User;
use Hash;

class ResetController extends Controller
{


    public function index(Request $request){
        $tokens =  $request ->token;
        return view('/reset')->with('token' , $tokens);
    
    }
 /*   public function FetchUrl(Request $request){
    	
    	

    }*/
    public function PasswordResets(Request $request){
        $rules = [
            'newpassword' => 'required|same:confirm_newpassword'
        ];
        $this->validate($request, $rules);
        $TokenTable =  DB::table('password_resets')->where('token' , 
            $request->tokenvalue)->first();
        $user =  User::where('email' , $TokenTable->email)->first();
        $hashed_password = Hash::make($request->newpassword);
        User::where('email' , $user->email)->update(['password' => $hashed_password]);
        session()->flash('Password-Updated','Passsword Updated Successfully ! Login Now');
        return redirect(route('login'));
    	
    }
}
