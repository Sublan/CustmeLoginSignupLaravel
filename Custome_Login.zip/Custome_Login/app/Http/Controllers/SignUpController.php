<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Hash;
use session;

class SignUpController extends Controller
{
    public function index (){
    	return view('signup');
    }

    public function store(Request $request){

/*        $rules = [
               
        ];*/
        // dd($request);
         // if($request->password == $request->password_confirmation){

             $this->validate($request, [ 
                'fname' => 'required|min:4|max:20',
                'lname' => 'required|min:4|max:20',
                'email' => 'required|email',
                'password' => 'min:8|required|same:password_confirmation'

            ]);
         // }
         // else{
         //    return redirect(route('signup'));
         // }

            /* $user = User::where('email',$request->email)->get();
       if ($user) {
         session()->flash('Email_Exists','This Email Already Exists');
         return redirect(route('signup'));
       }*/

    	$hashed_password = Hash::make($request->password);
         $user = User::create([
            'firstname'=> $request->fname,
            'lastname'=> $request->lname,
            'email'=> $request->email,
            'password'=> $hashed_password,
            'gender'=> $request->gendre

    ]);
      // $user->save();
    	/*$db_data->firstname = $req->fname;
    	$db_data->lastname = $req->lname;
    	$db_data->email = $req->email;
    	$db_data->password = $hashed_password;
    	$db_data->gender = $req->gendre;

    	$db_data->save();*/
    	session()->flash('success','SignUp Completed Login Here');
    	return redirect(route('login'));
    }

}
