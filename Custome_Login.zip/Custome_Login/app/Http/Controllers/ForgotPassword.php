<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\Mail\ForgotEmail;
use session;
use Auth;
use Hash;
use DB;
use Mail;
use Message;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Foundation\Auth\ResetsPasswords;

class ForgotPassword extends Controller
{

	public function index(){
		return view('/forgotpassword');
	
    }

    public function SendPasswordResetEmail(Request $request){

        $rules =[
                'email' => 'required|email'
        ];
        $this->validate($request , $rules);
         $user = User::where('email', $request->email)->first();
        if ( !$user ){
                session()->flash('No-Email','No Such Recovery Email Found');
                return redirect()->back();
        } 
           

    //create a new token to be sent to the user. 
     DB::table('password_resets')->insert([
        'email' => $request->email,
        'token' => str::random(60), //change 60 to any length you want
        'created_at' => Carbon::now()
    ]);

    $tokenData = DB::table('password_resets')->where('email', $request->email)->first();
    $token = $tokenData->token;
    $email = $tokenData->email;
    $link = url("/Reset-Authenticated/");
    $mail_sent = Mail::to($email)->send(new ForgotEmail($token ,$link));
    session()->flash('Email_Sent','Reset Link Email-Sent to Email Address ');
    return redirect (route('login'));



  
   /* if ($this->SendsPasswordResetEmail($request->email, $tokenData->token)) {
                 session()->flash('Email_Sent','Email-Sent');
                return redirect()->back();
            }           
     else {
            session()->flash('Email_Sending_fails','Email Sending fails');
            return redirect()->back();
        }
    */

   /**
    * Send email to the email above with a link to your password reset
    * something like url('password-reset/' . $token)
    * Sending email varies according to your Laravel version. Very easy to implement
    */
}












    public function ResetPassword(Request $request){

        $rules=[
            'email'=>'email|required',
            'password'=>'required|min:8'

        ];
        $this->validate($request,$rules);

            $user = User::where('email', $request->email)->first();
            $hashd_password = Hash::make($request->password);

    		if($user->email == $request->email){
                $user->password = $hashd_password;
                session()->flash('Email','Email Found and Password Updated');
                return redirect()->intended('login');
    		}
    		else{
    			
    			return redirect()->back();
    		}

    }

}
