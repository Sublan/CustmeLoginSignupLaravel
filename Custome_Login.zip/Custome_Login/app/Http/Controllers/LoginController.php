<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use App\User;
use session;
use App\Http\Middleware\Authentication;
use Auth;

class LoginController extends Controller
{
    public function index(){
    	return view('/login');
    }
    public function redirectif(){
        return route('home');
    }
    public function Verification(Request $req){

      //  $remember = $req->remember;
        $rules = [
                'uemail' => 'required|email',
                'password' => 'required|min:8'
        ];
        $this->validate($req, $rules);

    	if(Auth::attempt(['email' => $req->uemail, 'password' => $req->password])){
            

				session()->flash('Login_Success','You are Authenticated: Login Success');
    		 	return redirect()->intended('home');
    			 	
    		}
    	else{
    		session()->flash('LoginError','Wrong Credentials');
    		return redirect(route('login'));
    	}
    }
    public function logout(){
    	   Auth::logout();
    	   return view('welcome');
    }
}
