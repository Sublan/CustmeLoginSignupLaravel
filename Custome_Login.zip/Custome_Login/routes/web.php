<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login','LoginController@index')->name('login');
Route::get('/signup','SignUpController@index')->name('signup');
/*Route::get('/reset', function(){
	return view('reset');
});*/

Route::middleware(['auth_1'])->group( function(){

	Route::get('Login-Verification', 'LoginController@redirectif')->name('Login-Verification');
	Route::get('/home' , 'HomeController@index')->name('home');

});
Route::post('Login-Verification','LoginController@Verification')->name('Login.Verification');
Route::post('/StoreData','SignUpController@store')->name('StoreData');
Route::get('/logout','LoginController@logout')->name('logout');
Route::get('Passsword-Reset','ForgotPassword@index')->name('Passsword-Reset');
Route::post('/email','ForgotPassword@SendPasswordResetEmail')->name('Send-Reset-Email');
Route::get('Reset-Authenticated{token}','ResetController@index')->name('Reset-Authenticated');
Route::post('Password-Resets','ResetController@PasswordResets')->name('Password-Resets');
Route::post('Reset-Verification','ForgotPassword@ResetPassword')->name('Reset-Verification');

